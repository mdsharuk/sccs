function changeContent(page) {
    var contentDiv = document.getElementById('content');

    switch (page) {
        case 'home':
            contentDiv.innerHTML = `
				<div class="capricciosa">
                <h4>capricciosa........................................... $30</h4>
                  <p>Sed luctus purus,sed dapibus ex condimentum sed.Vestibulum eget
                  imperdiet metus,varius facilisis nisl.Interger et sem eros.</p>
                </div>
                <div class="capricciosa">
                <h4>margherita........................................... $25</h4>
                  <p>Sed luctus purus,sed dapibus ex condimentum sed.Vestibulum eget
                  imperdiet metus,varius facilisis nisl.Interger et sem eros.</p>
                </div>
                <div class="capricciosa">
                <h4>vegetariana........................................... $35</h4>
                  <p>Sed luctus purus,sed dapibus ex condimentum sed.Vestibulum eget
                  imperdiet metus,varius facilisis nisl.Interger et sem eros.</p>
                </div>
                <div class="capricciosa">
                <h4>garlic lime........................................... $20</h4>
                  <p>Sed luctus purus,sed dapibus ex condimentum sed.Vestibulum eget
                  imperdiet metus,varius facilisis nisl.Interger et sem eros.</p>
                </div>
                <div class="capricciosa">
                <h4>capricciosa........................................... $30</h4>
                  <p>Sed luctus purus,sed dapibus ex condimentum sed.Vestibulum eget
                  imperdiet metus,varius facilisis nisl.Interger et sem eros.</p>
                </div>
			`;
            break;
        case 'about':
            contentDiv.innerHTML = `
			`;
            break;
        case 'contact':
            contentDiv.innerHTML =
                `
				`;
            break;
        case 'DESSERT':
            contentDiv.innerHTML =
                `
				`;
            break;
        case 'DRINK':
            contentDiv.innerHTML = `
				
			`;
            break;

        default:
            contentDiv.innerHTML = '<h2>Page not found!</h2>';
    }
}
